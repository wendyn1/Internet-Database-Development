/**
 * PageLens 网页速览 —— 内容脚本
 * 由弹窗通过 chrome.scripting 注入到当前页面，负责统计页面信息并执行页面操作。
 */
(function () {
  "use strict";

  // 防止重复注入导致事件重复绑定
  if (window.__PAGE_LENS_LOADED__) {
    return;
  }
  window.__PAGE_LENS_LOADED__ = true;

  var LINK_CLASS = "pagelens-link-highlight";
  var READING_CLASS = "pagelens-reading-mode";
  var STYLE_ID = "pagelens-style";

  /** 注入插件所需样式（只注入一次） */
  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) {
      return;
    }
    var style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = [
      "." + LINK_CLASS + " {",
      "  outline: 2px solid #f59e0b !important;",
      "  background: rgba(245, 158, 11, .18) !important;",
      "  border-radius: 3px !important;",
      "}",
      "html." + READING_CLASS + " body {",
      "  max-width: 820px !important;",
      "  margin: 0 auto !important;",
      "  padding: 32px 24px !important;",
      "  background: #fbf7ee !important;",
      "  color: #2b2b2b !important;",
      "  font-family: Georgia, 'Songti SC', 'SimSun', serif !important;",
      "  font-size: 18px !important;",
      "  line-height: 1.95 !important;",
      "}",
      "html." + READING_CLASS + " body * {",
      "  max-width: 100% !important;",
      "  background-image: none !important;",
      "}",
      ".pagelens-toast {",
      "  position: fixed; z-index: 2147483647; left: 50%; bottom: 40px;",
      "  transform: translateX(-50%); background: rgba(17, 24, 39, .92);",
      "  color: #fff; padding: 10px 18px; border-radius: 999px;",
      "  font: 14px/1.4 'Microsoft YaHei', sans-serif;",
      "  box-shadow: 0 8px 24px rgba(0,0,0,.25); pointer-events: none;",
      "}"
    ].join("\n");
    (document.head || document.documentElement).appendChild(style);
  }

  /** 统计当前页面信息 */
  function collectStats() {
    var text = (document.body ? document.body.innerText : "") || "";
    var compact = text.replace(/\s+/g, "");
    return {
      title: document.title || "(无标题)",
      url: location.href,
      charCount: compact.length,
      linkCount: document.querySelectorAll("a[href]").length,
      imageCount: document.querySelectorAll("img").length,
      formCount: document.forms.length,
      headings: document.querySelectorAll("h1, h2, h3").length
    };
  }

  /** 高亮 / 取消高亮页面内所有链接 */
  function highlightLinks(on) {
    ensureStyle();
    var links = document.querySelectorAll("a[href]");
    links.forEach(function (link) {
      link.classList.toggle(LINK_CLASS, on);
    });
    return links.length;
  }

  /** 收集页面图片地址（去重） */
  function collectImages() {
    var seen = {};
    var list = [];
    document.querySelectorAll("img").forEach(function (img) {
      var src = img.currentSrc || img.src;
      if (src && !seen[src]) {
        seen[src] = true;
        list.push(src);
      }
    });
    return list;
  }

  /** 切换阅读模式 */
  function toggleReadingMode(on) {
    ensureStyle();
    document.documentElement.classList.toggle(READING_CLASS, on);
    return on;
  }

  /** 页面内浮层提示 */
  function toast(message) {
    var old = document.querySelector(".pagelens-toast");
    if (old) {
      old.remove();
    }
    ensureStyle();
    var box = document.createElement("div");
    box.className = "pagelens-toast";
    box.textContent = message;
    document.body.appendChild(box);
    setTimeout(function () {
      box.remove();
    }, 2600);
  }

  /** 统计选中文字 */
  function selectionInfo() {
    var selected = (window.getSelection() || "").toString();
    var chinese = (selected.match(/[\u4e00-\u9fa5]/g) || []).length;
    return { total: selected.length, chinese: chinese };
  }

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    switch (message.type) {
      case "PL_GET_STATS":
        sendResponse(collectStats());
        break;
      case "PL_HIGHLIGHT_LINKS":
        sendResponse({ count: highlightLinks(!!message.on) });
        break;
      case "PL_COLLECT_IMAGES":
        sendResponse({ images: collectImages() });
        break;
      case "PL_READING_MODE":
        sendResponse({ on: toggleReadingMode(!!message.on) });
        break;
      case "PL_SHOW_TOAST":
        toast(message.text || "");
        sendResponse({ ok: true });
        break;
      default:
        break;
    }
    return true;
  });

  // 供右键菜单直接注入调用
  window.__pageLensSelectionInfo = selectionInfo;
  window.__pageLensToast = toast;
})();
