/**
 * PageLens 网页速览 —— 弹窗逻辑
 * 通过 chrome.scripting 注入 content.js，再用 chrome.tabs.sendMessage 与页面通信。
 */
"use strict";

var HAS_EXTENSION_API =
  typeof chrome !== "undefined" && chrome.tabs && chrome.scripting && chrome.runtime;

var currentTab = null;
var highlightOn = false;
var readingOn = false;

function $(id) {
  return document.getElementById(id);
}

function setStatus(text, warn) {
  var box = $("status");
  box.textContent = text;
  box.classList.toggle("warn", !!warn);
}

function fillStats(stats) {
  $("pageTitle").textContent = stats.title || "(无标题)";
  $("pageTitle").title = stats.title || "";
  $("statChars").textContent = stats.charCount;
  $("statLinks").textContent = stats.linkCount;
  $("statImages").textContent = stats.imageCount;
  $("statForms").textContent = stats.formCount;
  $("statHeadings").textContent = stats.headings;
  try {
    $("statDomain").textContent = new URL(stats.url).hostname.replace(/^www\./, "");
  } catch (e) {
    $("statDomain").textContent = "-";
  }
  $("urlText").textContent = stats.url || "";
}

function sendToPage(message) {
  return new Promise(function (resolve) {
    chrome.tabs.sendMessage(currentTab.id, message, function (response) {
      if (chrome.runtime.lastError) {
        resolve(null);
        return;
      }
      resolve(response);
    });
  });
}

function refreshStats() {
  if (!currentTab) {
    return;
  }
  return sendToPage({ type: "PL_GET_STATS" }).then(function (stats) {
    if (stats) {
      fillStats(stats);
      setStatus("统计已更新");
    } else {
      setStatus("无法读取页面内容，请刷新页面后重试", true);
    }
  });
}

function init() {
  if (!HAS_EXTENSION_API) {
    // 直接以普通网页方式打开时进入演示模式，便于截图与查看界面
    fillStats({
      title: "Web前端初探演示站 · 2026世界杯球队信息",
      url: "http://localhost:8765/",
      charCount: 268,
      linkCount: 3,
      imageCount: 0,
      formCount: 3,
      headings: 9
    });
    setStatus("预览模式：在 Chrome 中加载本扩展后，可统计任意网页");
    return;
  }

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    currentTab = tabs && tabs[0];
    if (!currentTab || !currentTab.id) {
      setStatus("未找到当前标签页", true);
      return;
    }
    chrome.scripting.executeScript(
      { target: { tabId: currentTab.id }, files: ["content.js"] },
      function () {
        if (chrome.runtime.lastError) {
          setStatus("当前页面禁止注入脚本（如 Chrome 应用商店页）", true);
          return;
        }
        refreshStats();
      }
    );
  });
}

document.addEventListener("DOMContentLoaded", function () {
  init();

  $("btnRefresh").addEventListener("click", function () {
    if (!HAS_EXTENSION_API) {
      setStatus("演示模式：功能按钮需在 Chrome 扩展中运行", true);
      return;
    }
    refreshStats();
  });

  $("btnHighlight").addEventListener("click", function () {
    if (!HAS_EXTENSION_API) {
      setStatus("演示模式：功能按钮需在 Chrome 扩展中运行", true);
      return;
    }
    highlightOn = !highlightOn;
    sendToPage({ type: "PL_HIGHLIGHT_LINKS", on: highlightOn }).then(function (res) {
      if (!res) {
        setStatus("操作失败，请刷新页面重试", true);
        return;
      }
      $("btnHighlight").textContent = highlightOn ? "取消高亮链接" : "高亮所有链接";
      $("btnHighlight").classList.toggle("active", highlightOn);
      setStatus(highlightOn ? "已高亮 " + res.count + " 个链接" : "已取消链接高亮");
    });
  });

  $("btnImages").addEventListener("click", function () {
    if (!HAS_EXTENSION_API) {
      setStatus("演示模式：功能按钮需在 Chrome 扩展中运行", true);
      return;
    }
    sendToPage({ type: "PL_COLLECT_IMAGES" }).then(function (res) {
      if (!res) {
        setStatus("操作失败，请刷新页面重试", true);
        return;
      }
      if (!res.images.length) {
        setStatus("当前页面没有图片");
        return;
      }
      navigator.clipboard.writeText(res.images.join("\n")).then(function () {
        setStatus("已复制 " + res.images.length + " 条图片地址");
      }, function () {
        setStatus("复制失败：浏览器未授予剪贴板权限", true);
      });
    });
  });

  $("btnReading").addEventListener("click", function () {
    if (!HAS_EXTENSION_API) {
      setStatus("演示模式：功能按钮需在 Chrome 扩展中运行", true);
      return;
    }
    readingOn = !readingOn;
    sendToPage({ type: "PL_READING_MODE", on: readingOn }).then(function (res) {
      if (!res) {
        setStatus("操作失败，请刷新页面重试", true);
        return;
      }
      $("btnReading").textContent = readingOn ? "退出阅读模式" : "开启阅读模式";
      $("btnReading").classList.toggle("active", readingOn);
      setStatus(readingOn ? "阅读模式已开启" : "阅读模式已关闭");
    });
  });

  $("btnSelection").addEventListener("click", function () {
    if (!HAS_EXTENSION_API) {
      setStatus("演示模式：功能按钮需在 Chrome 扩展中运行", true);
      return;
    }
    sendToPage({ type: "PL_SHOW_TOAST", text: "请先在页面中选中文字，再使用右键菜单统计" });
    setStatus("请在页面中选中文字后，右键选择“用 PageLens 统计选中文字”");
  });
});
