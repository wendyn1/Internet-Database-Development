/**
 * PageLens 网页速览 —— 后台 Service Worker
 * 负责创建右键菜单，并在点击菜单时统计选中文字。
 */
"use strict";

chrome.runtime.onInstalled.addListener(function () {
  chrome.contextMenus.create({
    id: "pagelens-count-selection",
    title: "用 PageLens 统计选中文字",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId !== "pagelens-count-selection" || !tab || !tab.id) {
    return;
  }
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: function () {
      var text = (window.getSelection() || "").toString();
      var chinese = (text.match(/[\u4e00-\u9fa5]/g) || []).length;
      var message = "选中 " + text.length + " 个字符，其中中文 " + chinese + " 个";
      var old = document.querySelector(".pagelens-toast");
      if (old) {
        old.remove();
      }
      var box = document.createElement("div");
      box.className = "pagelens-toast";
      box.textContent = message;
      box.style.cssText = [
        "position:fixed", "z-index:2147483647", "left:50%", "bottom:40px",
        "transform:translateX(-50%)", "background:rgba(17,24,39,.92)",
        "color:#fff", "padding:10px 18px", "border-radius:999px",
        "font:14px/1.4 'Microsoft YaHei',sans-serif",
        "box-shadow:0 8px 24px rgba(0,0,0,.25)", "pointer-events:none"
      ].join(";");
      document.body.appendChild(box);
      setTimeout(function () { box.remove(); }, 2600);
    }
  });
});
