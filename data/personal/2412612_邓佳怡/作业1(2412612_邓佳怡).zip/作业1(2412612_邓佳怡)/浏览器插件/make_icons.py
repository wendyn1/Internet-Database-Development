# -*- coding: utf-8 -*-
"""生成 PageLens 扩展图标。"""
import os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(__file__), "PageLens", "icons")
os.makedirs(OUT, exist_ok=True)

S = 512
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)

# 深蓝渐变背景（逐行插值）
for y in range(S):
    t = y / (S - 1)
    r = int(15 + (30 - 15) * t)
    g = int(23 + (58 - 23) * t)
    b = int(42 + (138 - 42) * t)
    d.line([(0, y), (S, y)], fill=(r, g, b, 255))

# 圆角遮罩
mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=110, fill=255)
img.putalpha(mask)

# 放大镜
d.ellipse([120, 100, 340, 320], outline=(255, 255, 255, 255), width=34)
d.line([320, 300, 410, 390], fill=(255, 255, 255, 255), width=42)

# 镜片内的高亮色块，象征页面内容
d.rounded_rectangle([170, 170, 290, 196], radius=8, fill=(250, 204, 21, 255))
d.rounded_rectangle([170, 212, 260, 238], radius=8, fill=(147, 197, 253, 255))

img.save(os.path.join(OUT, "icon128.png"))
img.resize((48, 48), Image.LANCZOS).save(os.path.join(OUT, "icon48.png"))
img.resize((16, 16), Image.LANCZOS).save(os.path.join(OUT, "icon16.png"))
print("icons written to", OUT)
