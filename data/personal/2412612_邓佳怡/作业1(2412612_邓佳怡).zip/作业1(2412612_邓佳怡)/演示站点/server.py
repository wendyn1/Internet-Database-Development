# -*- coding: utf-8 -*-
"""
个人作业1 —— Web 前端初探演示站服务端
功能：提供 GET /api/teams 查询接口与 POST /api/messages 留言接口，
      并把每次真实请求的数据包写入 request_log.jsonl，便于对照 DevTools。
运行：python server.py  ，浏览器访问 http://localhost:8765/
"""
import json
import os
from datetime import datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE_DIR, "request_log.jsonl")

TEAMS = [
    {"id": 1, "name": "阿根廷", "coach": "斯卡洛尼", "confederation": "南美洲", "fifaRank": 1, "titles": 3},
    {"id": 2, "name": "法国", "coach": "德尚", "confederation": "欧洲", "fifaRank": 2, "titles": 2},
    {"id": 3, "name": "西班牙", "coach": "德拉富恩特", "confederation": "欧洲", "fifaRank": 3, "titles": 1},
    {"id": 4, "name": "巴西", "coach": "安切洛蒂", "confederation": "南美洲", "fifaRank": 5, "titles": 5},
    {"id": 5, "name": "葡萄牙", "coach": "马丁内斯", "confederation": "欧洲", "fifaRank": 6, "titles": 0},
    {"id": 6, "name": "英格兰", "coach": "图赫尔", "confederation": "欧洲", "fifaRank": 4, "titles": 1},
]

MESSAGES = []


class DemoHandler(SimpleHTTPRequestHandler):
    """静态文件 + 两个 JSON 接口。"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def log_message(self, fmt, *args):
        # 终端里保留简要日志
        print("[%s] %s" % (datetime.now().strftime("%H:%M:%S"), fmt % args))

    def _send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Demo-Server", "personal-homework-1")
        self.end_headers()
        self.wfile.write(body)

    def _write_log(self, entry):
        entry["time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_PATH, "a", encoding="utf-8") as fp:
            fp.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/teams":
            keyword = parse_qs(parsed.query).get("keyword", [""])[0].strip()
            data = [t for t in TEAMS if keyword in t["name"] or keyword in t["coach"]]
            self._write_log({
                "method": "GET",
                "path": self.path,
                "query": parse_qs(parsed.query),
                "headers": dict(self.headers),
            })
            self._send_json({"code": 0, "keyword": keyword, "total": len(data), "data": data})
            return
        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/messages":
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length).decode("utf-8") if length else ""
            try:
                payload = json.loads(raw) if raw else {}
            except json.JSONDecodeError:
                self._send_json({"code": 400, "msg": "请求体不是合法 JSON"}, 400)
                return

            nickname = str(payload.get("nickname", "")).strip()
            content = str(payload.get("content", "")).strip()
            if not nickname or not content:
                self._send_json({"code": 422, "msg": "昵称和留言内容不能为空"}, 422)
                return

            item = {
                "id": len(MESSAGES) + 1,
                "nickname": nickname,
                "content": content,
                "createdAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            MESSAGES.append(item)
            self._write_log({
                "method": "POST",
                "path": self.path,
                "headers": dict(self.headers),
                "body": raw,
            })
            self._send_json({"code": 0, "msg": "留言提交成功", "data": item}, 201)
            return
        self._send_json({"code": 404, "msg": "接口不存在"}, 404)


if __name__ == "__main__":
    port = 8765
    print("演示站已启动： http://localhost:%d/" % port)
    ThreadingHTTPServer(("127.0.0.1", port), DemoHandler).serve_forever()
