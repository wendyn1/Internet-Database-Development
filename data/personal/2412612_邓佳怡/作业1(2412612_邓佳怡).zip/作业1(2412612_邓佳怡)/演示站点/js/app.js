/**
 * 个人作业1 —— 演示站脚本
 * 包含：GET/POST 请求发起与数据包展示；三条 jQuery 事件语句。
 */
$(function () {
  "use strict";

  /* ============================================================
   * 一、数据包面板：把实际请求与响应渲染成可读的报文
   * ============================================================ */
  function pretty(text) {
    try {
      return JSON.stringify(JSON.parse(text), null, 2);
    } catch (e) {
      return text || "(空)";
    }
  }

  function showPacket(method, path, reqHeaders, reqBody, xhr, resBody) {
    var reqLines = method + " " + path + " HTTP/1.1";
    reqLines += "\nHost: " + location.host;
    Object.keys(reqHeaders).forEach(function (key) {
      reqLines += "\n" + key + ": " + reqHeaders[key];
    });
    if (reqBody) {
      reqLines += "\n\n" + pretty(reqBody);
    }

    var statusLine = "HTTP/1.1 " + xhr.status + " " + (xhr.statusText || "");
    var resHeaders = (xhr.getAllResponseHeaders() || "").trim();
    var resLines = statusLine + (resHeaders ? "\n" + resHeaders : "") + "\n\n" + pretty(resBody);

    $("#packetMethod").text(method).removeClass("ghost");
    $("#packetStatus").text(xhr.status + " " + (xhr.statusText || "")).removeClass("ghost");
    $("#reqPacket").text(reqLines);
    $("#resPacket").text(resLines);
  }

  /* ============================================================
   * 二、GET 请求：查询球队
   * ============================================================ */
  $("#btnGet").on("click", function () {
    var keyword = $.trim($("#keyword").val());
    var path = "/api/teams?keyword=" + encodeURIComponent(keyword);
    var headers = {
      "Accept": "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
      "User-Agent": navigator.userAgent
    };

    $("#getResult").removeClass("ok err").text("请求发送中…");

    $.ajax({
      url: "/api/teams",
      method: "GET",
      data: { keyword: keyword },
      dataType: "json",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      success: function (data, textStatus, xhr) {
        var $box = $("#getResult").addClass("ok").empty();
        $box.append($("<div>").text("响应成功，共匹配 " + data.total + " 支球队："));
        if (data.total === 0) {
          $box.append($("<div>").text("没有找到匹配的球队，请更换关键字。"));
        } else {
          var $table = $("<table>").addClass("mini-table");
          var $head = $("<tr>").append("<th>ID</th><th>球队</th><th>主教练</th><th>FIFA排名</th>");
          $table.append($head);
          data.data.forEach(function (team) {
            $table.append(
              $("<tr>")
                .append($("<td>").text(team.id))
                .append($("<td>").text(team.name))
                .append($("<td>").text(team.coach))
                .append($("<td>").text(team.fifaRank))
            );
          });
          $box.append($table);
        }
        showPacket("GET", path, headers, "", xhr, xhr.responseText);
      },
      error: function (xhr) {
        $("#getResult").removeClass("ok").addClass("err").text("请求失败：" + xhr.status);
        showPacket("GET", path, headers, "", xhr, xhr.responseText);
      }
    });
  });

  /* ============================================================
   * 三、POST 请求：提交留言
   * ============================================================ */
  $("#btnPost").on("click", function () {
    var payload = {
      nickname: $.trim($("#nickname").val()),
      content: $.trim($("#content").val())
    };
    var body = JSON.stringify(payload);
    var headers = {
      "Accept": "application/json, text/javascript, */*; q=0.01",
      "Content-Type": "application/json; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest",
      "User-Agent": navigator.userAgent
    };

    $("#postResult").removeClass("ok err").text("请求发送中…");

    $.ajax({
      url: "/api/messages",
      method: "POST",
      data: body,
      contentType: "application/json; charset=UTF-8",
      dataType: "json",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      success: function (data, textStatus, xhr) {
        $("#postResult").addClass("ok").text(
          "提交成功（HTTP " + xhr.status + "）：" + data.msg +
          " 留言编号 " + data.data.id + "，昵称 " + data.data.nickname
        );
        showPacket("POST", "/api/messages", headers, body, xhr, xhr.responseText);
      },
      error: function (xhr) {
        var msg = "提交失败（HTTP " + xhr.status + "）";
        try { msg += "：" + JSON.parse(xhr.responseText).msg; } catch (e) {}
        $("#postResult").removeClass("ok").addClass("err").text(msg);
        showPacket("POST", "/api/messages", headers, body, xhr, xhr.responseText);
      }
    });
  });

  /* ============================================================
   * 四、三条 jQuery 事件语句
   * ============================================================ */

  // 语句①：点击点赞按钮，切换样式并累加计数
  $("#btnLike").on("click", function () {
    var liked = $(this).toggleClass("liked").hasClass("liked");
    var count = parseInt($("#likeCount").text(), 10);
    $("#likeCount").text(liked ? count + 1 : count - 1);
    $("#likeState").text(liked ? "已点赞" : "未点赞");
    $(this).contents().first().replaceWith(liked ? "♥ 已点赞 " : "♡ 点赞 ");
  });

  // 语句②：点击按钮，展开或收起球队列表
  $("#btnToggle").on("click", function () {
    var $btn = $(this);
    $("#teamList").slideToggle(300, function () {
      $btn.text($(this).is(":visible") ? "收起球队列表" : "展开球队列表");
    });
  });

  // 语句③：输入框实时筛选列表项
  $("#filterInput").on("input", function () {
    var keyword = $.trim($(this).val());
    var shown = 0;
    $("#filterList li").each(function () {
      var match = $(this).data("name").indexOf(keyword) !== -1;
      $(this).toggleClass("hide", !match);
      if (match) { shown += 1; }
    });
    $("#filterCount").text(shown);
  });
});
