<?php
/**
 * Template Name: 全宽赛事模板
 * Description: 无侧栏的全宽页面模板，供首页、球队、比赛和联系页使用。
 */

$hw_links = array(
	'teams'   => array( 'label' => '球队', 'url' => home_url( '/' ) ),
	'matches' => array( 'label' => '比赛', 'url' => home_url( '/' ) ),
	'contact' => array( 'label' => '联系', 'url' => home_url( '/' ) ),
);
foreach ( $hw_links as $slug => $item ) {
	$page = get_page_by_path( $slug );
	if ( $page ) {
		$hw_links[ $slug ]['url'] = get_permalink( $page );
	}
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'hw3' ); ?>>
<?php wp_body_open(); ?>

<header class="hw-header">
	<div class="hw-wrap hw-header-inner">
		<a class="hw-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<svg class="hw-crest" viewBox="0 0 120 140" aria-hidden="true">
				<defs>
					<clipPath id="hwShield">
						<path d="M60 4 L112 22 V72 C112 104 88 126 60 136 C32 126 8 104 8 72 V22 Z"/>
					</clipPath>
				</defs>
				<g clip-path="url(#hwShield)">
					<rect width="120" height="140" fill="#ffffff"/>
					<rect x="8" width="22" height="140" fill="#75AADB"/>
					<rect x="52" width="22" height="140" fill="#75AADB"/>
					<rect x="96" width="24" height="140" fill="#75AADB"/>
					<circle cx="63" cy="58" r="15" fill="#F6B40E"/>
					<circle cx="63" cy="58" r="6" fill="#E09B00"/>
				</g>
				<path d="M60 4 L112 22 V72 C112 104 88 126 60 136 C32 126 8 104 8 72 V22 Z"
				      fill="none" stroke="#0B1626" stroke-width="4"/>
			</svg>
			<span class="hw-brand-text">
				<strong><?php bloginfo( 'name' ); ?></strong>
				<em>FIFA WORLD CUP 2026 · TEAM ARCHIVE</em>
			</span>
		</a>

		<button class="hw-nav-toggle" type="button" aria-label="展开导航">☰</button>

		<nav class="hw-nav" aria-label="主导航">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="<?php echo is_front_page() ? 'is-active' : ''; ?>">首页</a>
			<a href="<?php echo esc_url( $hw_links['teams']['url'] ); ?>" class="<?php echo is_page( 'teams' ) ? 'is-active' : ''; ?>">球队</a>
			<a href="<?php echo esc_url( $hw_links['matches']['url'] ); ?>" class="<?php echo is_page( 'matches' ) ? 'is-active' : ''; ?>">比赛</a>
			<a href="<?php echo esc_url( home_url( '/#data' ) ); ?>">数据</a>
			<a href="<?php echo esc_url( $hw_links['contact']['url'] ); ?>" class="<?php echo is_page( 'contact' ) ? 'is-active' : ''; ?>">联系</a>
		</nav>

		<a class="hw-repo" href="https://github.com/wendyn1/Internet-Database-Development" target="_blank" rel="noopener">
			<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 0 0-3.2 19.5c.5.1.7-.2.7-.5v-1.8c-2.8.6-3.4-1.2-3.4-1.2-.4-1.1-1.1-1.4-1.1-1.4-.9-.6.1-.6.1-.6 1 .1 1.5 1 1.5 1 1 1.7 2.6 1.2 3.2.9.1-.7.4-1.2.7-1.5-2.2-.2-4.6-1.1-4.6-5 0-1.1.4-2 1-2.7-.1-.2-.4-1.2.1-2.6 0 0 .8-.3 2.7 1a9.3 9.3 0 0 1 5 0c1.9-1.3 2.7-1 2.7-1 .5 1.4.2 2.4.1 2.6.6.7 1 1.6 1 2.7 0 3.9-2.4 4.8-4.6 5 .4.3.7.9.7 1.9v2.8c0 .3.2.6.7.5A10 10 0 0 0 12 2z" fill="currentColor"/></svg>
			<span>作业仓库</span>
		</a>
	</div>
</header>

<main id="content" class="hw-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'hw-page' ); ?>>
			<?php the_content(); ?>
		</article>
	<?php endwhile; ?>
</main>

<footer class="hw-footer">
	<div class="hw-wrap hw-footer-grid">
		<div>
			<div class="hw-footer-brand">
				<svg class="hw-crest" viewBox="0 0 120 140" aria-hidden="true">
					<defs>
						<clipPath id="hwShieldFoot">
							<path d="M60 4 L112 22 V72 C112 104 88 126 60 136 C32 126 8 104 8 72 V22 Z"/>
						</clipPath>
					</defs>
					<g clip-path="url(#hwShieldFoot)">
						<rect width="120" height="140" fill="#ffffff"/>
						<rect x="8" width="22" height="140" fill="#75AADB"/>
						<rect x="52" width="22" height="140" fill="#75AADB"/>
						<rect x="96" width="24" height="140" fill="#75AADB"/>
						<circle cx="63" cy="58" r="15" fill="#F6B40E"/>
					</g>
				</svg>
				<strong><?php bloginfo( 'name' ); ?></strong>
			</div>
			<p>课程设计样本站点，围绕 2026 世界杯精选球队展示球队、球员、比赛与荣誉。数据范围以页面标注为准。</p>
		</div>
		<div class="hw-footer-col">
			<h4>快速入口</h4>
			<a href="<?php echo esc_url( $hw_links['teams']['url'] ); ?>">精选球队</a>
			<a href="<?php echo esc_url( $hw_links['matches']['url'] ); ?>">已收录比赛</a>
			<a href="<?php echo esc_url( home_url( '/#data' ) ); ?>">数据图表</a>
		</div>
		<div class="hw-footer-col">
			<h4>课程资料</h4>
			<a href="https://github.com/wendyn1/Internet-Database-Development" target="_blank" rel="noopener">团队作业仓库</a>
			<a href="https://github.com/wendyn1/Internet-Database-Development" target="_blank" rel="noopener">个人作业仓库</a>
			<span>互联网数据库开发 · 个人作业3</span>
		</div>
	</div>
	<div class="hw-footer-bottom">
		<div class="hw-wrap">
			<span>© <?php echo esc_html( date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></span>
			<span>2412612 邓佳怡 · WordPress 课程实验</span>
		</div>
	</div>
</footer>

<script>
(function () {
	var toggle = document.querySelector('.hw-nav-toggle');
	var nav = document.querySelector('.hw-nav');
	if (toggle && nav) {
		toggle.addEventListener('click', function () {
			nav.classList.toggle('is-open');
		});
	}
})();
</script>

<?php wp_footer(); ?>
</body>
</html>
