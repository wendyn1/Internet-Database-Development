<?php
/**
 * HW3 世界杯赛事子主题函数。
 */

add_action( 'wp_enqueue_scripts', function () {
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style(
		'hw3-site',
		get_stylesheet_directory_uri() . '/assets/site.css',
		array(),
		$version
	);
} );

/**
 * 让页面模板支持标题隐藏等常规能力。
 */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
} );
