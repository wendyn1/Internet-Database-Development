<?php
/**
 * 作业3 站点初始化脚本。
 * 运行方式：
 *   D:\xampp\php\php.exe seed.php
 *
 * 作用：启用子主题与 Contact Form 7，创建首页、球队、比赛、联系四个页面，
 * 写入页面内容并设置静态首页。
 */

require_once 'D:/xampp/htdocs/wordpress/wp-load.php';

function hw_log( $message ) {
	echo $message . PHP_EOL;
}

/* 1. 启用子主题 */
switch_theme( 'blocksy-child' );
hw_log( '主题：' . wp_get_theme()->get( 'Name' ) );

/* 2. 启用 Contact Form 7 */
$plugin = 'contact-form-7/wp-contact-form-7.php';
if ( ! is_plugin_active( $plugin ) ) {
	$result = activate_plugin( $plugin );
	if ( is_wp_error( $result ) ) {
		hw_log( '插件启用失败：' . $result->get_error_message() );
	} else {
		hw_log( '插件已启用：Contact Form 7' );
	}
} else {
	hw_log( '插件已启用：Contact Form 7' );
}

/* 3. 站点基础设置 */
update_option( 'blogname', '2026世界杯球队信息系统' );
update_option( 'blogdescription', '2026 世界杯精选球队资料与比赛数据' );
update_option( 'timezone_string', 'Asia/Shanghai' );
update_option( 'date_format', 'Y-m-d' );
update_option( 'permalink_structure', '/%postname%/' );

/* 4. 创建或更新页面 */
$pages = array(
	'home'    => array( 'title' => '首页', 'file' => 'home.html' ),
	'teams'   => array( 'title' => '球队', 'file' => 'teams.html' ),
	'matches' => array( 'title' => '比赛', 'file' => 'matches.html' ),
	'contact' => array( 'title' => '联系', 'file' => 'contact.html' ),
);

$ids = array();
foreach ( $pages as $slug => $config ) {
	$existing = get_page_by_path( $slug );
	if ( $existing ) {
		$ids[ $slug ] = $existing->ID;
		hw_log( '页面已存在：' . $config['title'] . ' (#' . $existing->ID . ')' );
		continue;
	}
	$id = wp_insert_post( array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => $config['title'],
		'post_name'    => $slug,
		'post_content' => '',
	) );
	if ( is_wp_error( $id ) ) {
		hw_log( '页面创建失败：' . $config['title'] . ' - ' . $id->get_error_message() );
		continue;
	}
	$ids[ $slug ] = $id;
	hw_log( '页面已创建：' . $config['title'] . ' (#' . $id . ')' );
}

foreach ( $ids as $slug => $id ) {
	update_post_meta( $id, '_wp_page_template', 'page-templates/landing.php' );
}

/* 5. 生成页面内容 */
$links = array(
	'{{HOME}}'    => home_url( '/' ),
	'{{TEAMS}}'   => get_permalink( $ids['teams'] ),
	'{{MATCHES}}' => get_permalink( $ids['matches'] ),
	'{{CONTACT}}' => get_permalink( $ids['contact'] ),
);

$forms = get_posts( array(
	'post_type'   => 'wpcf7_contact_form',
	'numberposts' => 1,
	'post_status' => 'any',
) );
$cf7 = '';
if ( $forms ) {
	$cf7 = '[contact-form-7 id="' . $forms[0]->ID . '" title="' . esc_attr( $forms[0]->post_title ) . '"]';
	hw_log( 'Contact Form 7 表单 ID：' . $forms[0]->ID );
} else {
	hw_log( '警告：未找到 Contact Form 7 表单。' );
}

foreach ( $pages as $slug => $config ) {
	$path = __DIR__ . '/内容/' . $config['file'];
	if ( ! file_exists( $path ) ) {
		hw_log( '缺少内容文件：' . $path );
		continue;
	}
	$content = file_get_contents( $path );
	$content = strtr( $content, $links );
	$content = str_replace( '{{CF7}}', $cf7, $content );

	wp_update_post( array(
		'ID'           => $ids[ $slug ],
		'post_content' => $content,
	) );
	hw_log( '内容已写入：' . $config['title'] );
}

/* 6. 静态首页 */
update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $ids['home'] );
update_option( 'page_for_posts', 0 );
hw_log( '静态首页：' . $ids['home'] );

flush_rewrite_rules( true );
hw_log( '固定链接已刷新：' . get_option( 'permalink_structure' ) );
hw_log( '完成。首页地址：' . home_url( '/' ) );
