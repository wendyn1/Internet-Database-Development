# B站视频书签（浏览器插件）

个人作业1 · 任务3 —— 2413423 王乐妍

## 功能

在 Bilibili 视频页面（`www.bilibili.com/video/*`）右侧插入一个"视频书签"面板：

- 点击按钮记录当前播放时间点，并可为书签添加文字笔记；
- 书签保存在 `chrome.storage`（按视频 BV 号区分），下次打开同一视频自动恢复；
- 点击任一书签即可让播放器跳转到对应时间点；
- 支持删除书签，面板样式通过 content.css 定制。

## 文件说明

| 文件 | 作用 |
|---|---|
| `manifest.json` | 插件清单：MV3 配置、storage 权限、内容脚本注入规则 |
| `content.js` | 核心逻辑：注入书签面板、读写 storage、与播放器交互 |
| `content.css` | 书签面板样式 |

## 安装方法

1. 打开 Chrome/Edge，进入 `edge://extensions/`（或 `chrome://extensions/`）；
2. 打开右上角"开发人员模式"；
3. 点击"加载解压缩的扩展"，选择本文件夹即可。
