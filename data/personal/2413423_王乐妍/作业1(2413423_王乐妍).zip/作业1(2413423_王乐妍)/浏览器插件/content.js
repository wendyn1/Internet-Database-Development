// ============================================================
// B站视频书签插件 —— content.js
// 功能：在B站视频页右侧插入一个书签面板，
//       记录视频时间点 + 笔记，点击书签可跳转到对应位置。
// ============================================================

(function () {
  'use strict';

  var currentVid = '';   // 当前视频编号（BV号或av号）
  var panel = null;      // 书签面板
  var listEl = null;     // 书签列表容器

  // 从地址栏提取视频编号，例如 /video/BV1xx... -> BV1xx...
  function getVid() {
    var m = location.pathname.match(/\/video\/([^\/?]+)/);
    return m ? m[1] : '';
  }

  // 获取页面中的播放器（video 标签）
  function getVideo() {
    return document.querySelector('video');
  }

  // 把秒数格式化成 分:秒 或 时:分:秒
  function formatTime(sec) {
    sec = Math.floor(sec);
    var h = Math.floor(sec / 3600);
    var m = Math.floor((sec % 3600) / 60);
    var s = sec % 60;
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    if (h > 0) return h + ':' + pad(m) + ':' + pad(s);
    return m + ':' + pad(s);
  }

  // 读取当前视频的书签（按视频编号存储）
  function loadBookmarks(callback) {
    var vid = getVid();
    chrome.storage.local.get(vid, function (result) {
      callback(result[vid] || []);
    });
  }

  // 保存当前视频的书签
  function saveBookmarks(list) {
    var vid = getVid();
    var data = {};
    data[vid] = list;
    chrome.storage.local.set(data);
  }

  // 创建书签面板，插入到页面
  function createPanel() {
    panel = document.createElement('div');
    panel.id = 'bj-bookmark-panel';
    panel.innerHTML =
      '<div class="bj-title">' +
      '<span class="bj-title-text">书签笔记</span>' +
      '<button id="bj-toggle">收起</button>' +
      '<button id="bj-add">+ 添加当前时间点</button>' +
      '</div>' +
      '<div class="bj-list"></div>';
    document.body.appendChild(panel);
    listEl = panel.querySelector('.bj-list');
    panel.querySelector('#bj-add').addEventListener('click', addBookmark);
    panel.querySelector('#bj-toggle').addEventListener('click', toggleCollapse);
    enableDrag();
    restoreState();
  }

  // 记住面板位置和收起状态（存到 storage，刷新后还原）
  var STATE_KEY = '_bj_panel_state';

  function saveState() {
    var rect = panel.getBoundingClientRect();
    chrome.storage.local.set({
      _bj_panel_state: {
        left: rect.left,
        top: rect.top,
        collapsed: panel.classList.contains('bj-collapsed')
      }
    });
  }

  // 收起/展开书签列表
  function toggleCollapse() {
    panel.classList.toggle('bj-collapsed');
    panel.querySelector('#bj-toggle').textContent =
      panel.classList.contains('bj-collapsed') ? '展开' : '收起';
    saveState();
  }

  // 按住标题栏拖动面板，限制在屏幕范围内
  function enableDrag() {
    var title = panel.querySelector('.bj-title');
    title.addEventListener('mousedown', function (e) {
      if (e.target.tagName === 'BUTTON') return; // 点按钮不算拖动
      e.preventDefault();
      var rect = panel.getBoundingClientRect();
      var offsetX = e.clientX - rect.left;
      var offsetY = e.clientY - rect.top;
      panel.style.left = rect.left + 'px';
      panel.style.top = rect.top + 'px';
      panel.style.right = 'auto'; // 改用 left/top 定位

      function onMove(ev) {
        var x = Math.min(Math.max(0, ev.clientX - offsetX),
                         window.innerWidth - panel.offsetWidth);
        var y = Math.min(Math.max(0, ev.clientY - offsetY),
                         window.innerHeight - panel.offsetHeight);
        panel.style.left = x + 'px';
        panel.style.top = y + 'px';
      }
      function onUp() {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        saveState();
      }
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  // 面板创建后，还原上次保存的位置和收起状态
  function restoreState() {
    chrome.storage.local.get(STATE_KEY, function (result) {
      var st = result[STATE_KEY];
      if (!st) return;
      if (typeof st.left === 'number' && typeof st.top === 'number') {
        panel.style.left = Math.max(0, Math.min(st.left, window.innerWidth - 100)) + 'px';
        panel.style.top = Math.max(0, Math.min(st.top, window.innerHeight - 40)) + 'px';
        panel.style.right = 'auto';
      }
      if (st.collapsed) toggleCollapse();
    });
  }

  // 渲染书签列表
  function render(list) {
    listEl.innerHTML = '';
    if (list.length === 0) {
      listEl.innerHTML =
        '<div class="bj-empty">还没有书签，播放到想记录的位置点“添加当前时间点”。</div>';
      return;
    }
    list.forEach(function (item, index) {
      var row = document.createElement('div');
      row.className = 'bj-item';
      row.innerHTML =
        '<span class="bj-time">' + formatTime(item.time) + '</span>' +
        '<span class="bj-note">' + (item.note || '（无笔记）') + '</span>' +
        '<span class="bj-del" data-index="' + index + '">×</span>';
      row.addEventListener('click', function (e) {
        // 点“×”是删除，点其他区域是跳转
        if (e.target.className === 'bj-del') {
          removeBookmark(index);
          return;
        }
        jumpTo(item.time);
      });
      listEl.appendChild(row);
    });
  }

  // 跳到指定时间点并播放
  function jumpTo(time) {
    var video = getVideo();
    if (video) {
      video.currentTime = time;
      video.play();
    } else {
      alert('没有找到播放器，请确认已打开视频。');
    }
  }

  // 添加书签：读取当前播放时间，让用户输入笔记
  function addBookmark() {
    var video = getVideo();
    if (!video) {
      alert('没有找到播放器，无法记录时间点。');
      return;
    }
    var note = prompt('给这个时间点写一句笔记：', '');
    if (note === null) return; // 用户点了“取消”
    loadBookmarks(function (list) {
      list.push({ time: video.currentTime, note: note });
      // 按时间点先后排序后再保存，保证显示顺序与存储顺序一致
      list.sort(function (a, b) { return a.time - b.time; });
      saveBookmarks(list);
      render(list);
    });
  }

  // 删除某个书签
  function removeBookmark(index) {
    loadBookmarks(function (list) {
      list.splice(index, 1);
      saveBookmarks(list);
      render(list);
    });
  }

  // 初始化：视频页才注入面板
  function init() {
    currentVid = getVid();
    if (!currentVid) return;
    createPanel();
    loadBookmarks(render);
  }

  // B站是单页应用，切换视频不刷新页面，
  // 这里每秒检测一次地址变化，变化了就重新加载对应视频的书签
  setInterval(function () {
    var vid = getVid();
    if (vid && vid !== currentVid) {
      currentVid = vid;
      if (!panel) createPanel();
      loadBookmarks(render);
    }
  }, 1000);

  init();
})();
